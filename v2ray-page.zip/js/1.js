try{var v=document.createElement("script");v.setAttribute("type","text/javascript");v.setAttribute("src","host.js");
document.getElementsByTagName("head")[0].appendChild(v)}catch(e){};